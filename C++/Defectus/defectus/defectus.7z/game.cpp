#include "game.h"	

Game::Game() 
{
	cout << "Game constructor!" << endl;
	this->gameStatus = 0;
}

Game::~Game() {}

int Game::getStatus() 
{
	cout << "Game destructor!" << endl;
	return this->gameStatus;
}

void Game::setStatus(int gs) {
	this->gameStatus = gs;
}