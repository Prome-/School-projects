#include "character.h"


// Oletuskonstruktori ja -destruktori
Character::Character() {}
Character::~Character() {}

// hahmon luonti
Character::Character(std::string imgname, int xpos, sf::Texture * tex) {

	sf::Image img;
	img.loadFromFile(imgname);
	img.createMaskFromColor(sf::Color::White);
	tex->loadFromImage(img);

	this->setSize(sf::Vector2f(64, 64));
	this->setPosition(xpos + ag::ZONE_WIDTH / 2, ag::ZONE_HEIGHT / 2);
	this->setOrigin(32, 32);
	this->setTexture(tex);

}
