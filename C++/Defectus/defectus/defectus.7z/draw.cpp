#include "draw.h"

Draw::Draw()
{
	cout << "Draw constructor!" << endl;
}

Draw::~Draw()
{
	cout << "Draw destructor!" << endl;
}

void Draw::drawBlocks(sf::RectangleShape ***&ptrarray, sf::Texture &blockTex, sf::RenderWindow &window)
{
	for (int a = 0; a < ag::ZONE_HEIGHT / ag::BLOCK_HEIGHT; a++)
	{
		for (int b = 0; b < ag::ZONE_HEIGHT / ag::BLOCK_HEIGHT; b++)
		{
			ptrarray[a][b]->setTexture(&blockTex);
			window.draw(*ptrarray[a][b]);
		}
	}
}

void Draw::drawMole(sf::RectangleShape &mole, sf::RenderWindow &window)
{
	window.draw(mole);
}

void Draw::drawBullet(sf::RectangleShape &bullet, sf::RenderWindow &window)
{
	window.draw(bullet);
}