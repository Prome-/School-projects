#ifndef drawh
#define drawh
#include "globals.h"

class Draw {
public:
	Draw();
	~Draw();
	void drawBlocks(sf::RectangleShape ***&, sf::Texture &, sf::RenderWindow &);
	void drawMole(sf::RectangleShape &, sf::RenderWindow &);
	void drawBullet(sf::RectangleShape &, sf::RenderWindow &);
};


#endif