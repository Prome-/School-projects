#ifndef gameh
#define gameh
#include "globals.h"
class Game {
private:
	int gameStatus;
public:
	Game();
	~Game();
	int getStatus();
	void setStatus(int);	// Asettaa gamestatuksen: [0|1]
	

};

#endif