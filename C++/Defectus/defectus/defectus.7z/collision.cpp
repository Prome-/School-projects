#include "collision.h"

Collision::Collision()
{
	cout << "Collision constructor!" << endl;
}
Collision::~Collision()
{
	cout << "Collision destructor!" << endl;
}

void Collision::checkCollision(sf::RectangleShape ***& ptrarray, sf::RectangleShape &mole, struct bulletChain *&firstLink)
{
	for (int a = 0; a < ag::ZONE_HEIGHT / ag::BLOCK_HEIGHT; a++)
	{
		for (int b = 0; b < ag::ZONE_HEIGHT / ag::BLOCK_HEIGHT; b++)
		{
			// myyr�n ja blockien collision
			if (mole.getGlobalBounds().intersects(ptrarray[a][b]->getGlobalBounds()))
			{
				ptrarray[a][b]->setPosition(ag::ZONE_HEIGHT * 2, ag::ZONE_WIDTH * 2);
			}
			// ammusten ja blockien collision
			while (firstLink->nextLink)
			{
				if (firstLink->thisBullet.getGlobalBounds().intersects(ptrarray[a][b]->getGlobalBounds()))
				{
					ptrarray[a][b]->setPosition(ag::ZONE_HEIGHT * 2, ag::ZONE_WIDTH * 2);
				}
			}
			// tarkistetaan viel� linked listin viimeisen otuksen collision blockien kanssa
			if (firstLink->thisBullet.getGlobalBounds().intersects(ptrarray[a][b]->getGlobalBounds()))
			{
				ptrarray[a][b]->setPosition(ag::ZONE_HEIGHT * 2, ag::ZONE_WIDTH * 2);
			}

		}
	}
}