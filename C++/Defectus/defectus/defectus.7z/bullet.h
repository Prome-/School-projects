#ifndef bulleth
#define bulleth
#include "globals.h"

class Bullet : public sf::RectangleShape
{

public:
	Bullet();
	Bullet(int, int, sf::Texture *);
	~Bullet();
	int addBullet(sf::RectangleShape, sf::Texture *, struct bulletChain *&);

};

#endif