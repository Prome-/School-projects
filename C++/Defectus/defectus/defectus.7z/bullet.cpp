#include "bullet.h"

Bullet::Bullet(int xpos, int ypos, sf::Texture *bulletTex)
{
	cout << "Bullet overloaded constructor!" << endl;

	sf::Image img;
	img.loadFromFile("Glenos - G_160_bullet.png");
	img.createMaskFromColor(sf::Color::White);
	bulletTex->loadFromImage(img);

	this->setSize(sf::Vector2f(2, 2));
	this->setPosition(xpos, ypos);
	//this->setOrigin(32, 32);
	this->setTexture(bulletTex);
}

Bullet::Bullet()
{ 
	cout << "Bullet constructor!" << endl;
	sf::Image img;
	sf::Texture tex;
	img.loadFromFile("Glenos - G_160_bullet.png");
	tex.loadFromImage(img);
	this->setSize(sf::Vector2f(2, 2));
	this->setFillColor(sf::Color::White);
	this->setTexture(&tex);
	
};

Bullet::~Bullet()
{
	cout << "Bullet destructor!" << endl;
}


// luodaan luoti ja laitetaan se linked listiin
int Bullet::addBullet(sf::RectangleShape mole, sf::Texture *tex, struct bulletChain *&firstLink)
{
	Bullet newBullet; // = new Bullet(mole.getPosition(), tex);
	newBullet.setPosition(0,0);
	bulletChain *newLink = new bulletChain;
	
	if (newLink) 
	{
		newLink->nextLink = NULL;
		newLink->thisBullet = newBullet;
		bulletChain *thisLink = new bulletChain;
		
		if (!firstLink) { firstLink = newLink; }
		else 
		{
			thisLink = firstLink;
			while (thisLink->nextLink)
			{
				thisLink = thisLink->nextLink;
			}

			thisLink->nextLink = newLink;
		}
		return 1;
	}
	else {
		return 0;
	}
	return 0;
}
