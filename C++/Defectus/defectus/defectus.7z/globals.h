#ifndef globalsh
#define globalsh
#include <iostream>
#include <math.h>
#include <string>
#include <SFML/Graphics.hpp>
#include "game.h"
#include "character.h"
#include "event.h"
#include "zone.h"
#include "motion.h"
#include "bullet.h"
#include "collision.h"
#include "draw.h"

using namespace std;

struct bulletChain
{
	Bullet thisBullet;
	bulletChain *nextLink;
};


namespace  ag
{
	const int BLOCK_HEIGHT = 10;
	const int BLOCK_WIDTH = 10;
	const int ZONE_WIDTH = 500;
	const int ZONE_HEIGHT = 500;
	const int BORDER_LIMIT = 20;
	const int COLLISION_LIMIT = 30;
	const int CHARACTER_DISTANCE = 100;
	const float GAME_SPEED = 200.0f;
}

#endif