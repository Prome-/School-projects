#include "motion.h"

Motion::Motion() {

}

void Motion::move(int button, sf::RectangleShape &mole) {

	switch (button) {

	case 0:
		std::cout << std::endl << "Ylos painettu" << std::endl;
		mole.move(0, -1);
		print(mole);
		break;
	case 1:
		std::cout << std::endl << "Oikealle painettu" << std::endl;
		mole.move(1, 0);
		print(mole);
		break;
	case 2:
		std::cout << std::endl << "Alas painettu" << std::endl;
		mole.move(0, 1);
		print(mole);
		break;
	case 3:
		std::cout << std::endl << "Vasemmalle painettu" << std::endl;
		mole.move(-1, 0);
		print(mole);
		break;
	}
}

void Motion::print(sf::RectangleShape mole) {

	sf::Vector2f pos = mole.getPosition();

	int x, y;

	x = pos.x;
	y = pos.y;

	std::cout << "positio: " << x << "," << y;
}