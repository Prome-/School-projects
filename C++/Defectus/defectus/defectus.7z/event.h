#ifndef eventh
#define eventh
#include "globals.h"
class Event {
public:
	Event();
	~Event();
	void handleWindow(sf::RenderWindow &);  // ikkunan osoite
	void handleShot(sf::RenderWindow &);

};
#endif