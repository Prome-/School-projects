#ifndef zoneh
#define zoneh
#include "globals.h"

using namespace std;

class Zone : public sf::RectangleShape
{
public:
	Zone();
	~Zone();
	void createBitMap(RectangleShape ***&);

};




#endif