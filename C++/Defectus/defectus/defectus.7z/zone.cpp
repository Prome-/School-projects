#include "zone.h"


Zone::Zone()
{
	cout << "Zone konstruktori!" << endl;
}

Zone::~Zone()
{
	cout << "Zone destruktori!" << endl;
}

void Zone::createBitMap(sf::RectangleShape ***& ptrarray) 
{
	ptrarray = new RectangleShape** [ag::ZONE_HEIGHT];

	for (int a = 0;a < ag::ZONE_HEIGHT/ag::BLOCK_HEIGHT;a++)
	{
		ptrarray[a] = new RectangleShape*[ag::ZONE_WIDTH/ag::BLOCK_WIDTH];
	}

	for (int a = 0; a < ag::ZONE_HEIGHT / ag::BLOCK_HEIGHT;a++)
	{
		for (int b = 0; b < ag::ZONE_WIDTH/ag::BLOCK_WIDTH;b++)
		{
			ptrarray[a][b] = new RectangleShape(sf::Vector2f(ag::BLOCK_WIDTH, ag::BLOCK_HEIGHT));
			ptrarray[a][b]->setPosition(a*ag::BLOCK_HEIGHT, b*ag::BLOCK_WIDTH);

			cout << "Luodaan ruutu! " <<  endl;
		}	
	}	
}

