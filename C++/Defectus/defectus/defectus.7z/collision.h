#ifndef collisionh
#define collisionh
#include "globals.h"

class Collision
{
public:
	Collision();
	~Collision();
	void checkCollision(sf::RectangleShape ***&, sf::RectangleShape &, struct bulletChain *&);
};


#endif