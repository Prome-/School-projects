#ifndef characterh
#define characterh
#include "globals.h"
class Character : public sf::RectangleShape {

public:
	Character();
	~Character();
	Character(std::string, int, sf::Texture *);
};
#endif