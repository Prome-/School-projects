#include "globals.h"



void main() 
{
	// olioiden alustus
	Game newGame;
	Event newEvent;
	Zone newZone;
	Motion newMotion;
	Collision newCollision;
	Draw newDraw;
	Bullet newBullet;
	sf::Clock newClock;
	sf::Texture moleTex;
	bulletChain *firstLink = NULL;
	
	// blockien alustus ja iterointi taulukkoon
	sf::RectangleShape ***ptrarray = NULL;
	newZone.createBitMap(ptrarray);
	sf::Image blockImg;
	blockImg.loadFromFile("Brick250a.jpg");
	sf::Texture blockTex;
	blockTex.loadFromImage(blockImg);

	// hahmon alustus
	Character mole("mole_standing_right.png", ag::CHARACTER_DISTANCE, &moleTex);
	
	// ikkunan alustus
	sf::RenderWindow window(sf::VideoMode(ag::ZONE_WIDTH, ag::ZONE_HEIGHT), "MYYRAMIES!");
	
	newGame.setStatus(1);

	// pelilooppi
	while (window.isOpen()) {
		
		float d = newClock.restart().asSeconds();
		float transition = d * ag::GAME_SPEED;
		newEvent.handleWindow(window);
		
		if (newGame.getStatus() == 1)
		{
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
			{
				newMotion.move(0, mole);
			}
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
			{
				newMotion.move(1, mole);
			}
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
			{
				newMotion.move(2, mole);
			}
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
			{
				newMotion.move(3, mole);
			}
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
			{
				/*
				int x, y;
				x << sf::Mouse::getPosition(window).x;
				y << sf::Mouse::getPosition(window).y;
				cout << "X: " << x << endl;
				cout << "Y: " << y << endl;
				*/
			}
			window.clear();
			newCollision.checkCollision(ptrarray, mole, firstLink);
			newDraw.drawBlocks(ptrarray, blockTex, window);
			newDraw.drawMole(mole, window);
			window.display();
		}	
	}
}