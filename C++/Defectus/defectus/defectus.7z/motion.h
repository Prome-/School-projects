#ifndef motionh
#define motionh
#include "globals.h"


class Motion {
private:
	void print(sf::RectangleShape);
public:
	Motion();
	void move(int, sf::RectangleShape&);
};

#endif